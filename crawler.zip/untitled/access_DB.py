import pymysql

#측정소 정보를 sql로 저장
def place_insert(info):
    # MySQL Connection 연결
    conn = pymysql.connect(host='localhost', user='root', password='a0415312',
                           db='openair', charset='utf8')
    try:
        # Connection 으로부터  Cursor 생성
        # INSERT
        with conn.cursor() as curs:
            sql = """insert into realtimew(place,address) values (%s, %s)"""
            curs.executemany(sql, info)

        conn.commit()

        # SELECT
        with conn.cursor() as curs:
            sql = "select * FROM realtimew"
            curs.execute(sql)
            rs = curs.fetchall()
            for row in rs:
                print(row)

    finally:
        conn.close()

#실시간 날씨 정보 sql로 저장
def realtimew_update(info):
    # MySQL Connection 연결
    conn = pymysql.connect(host='localhost', user='root', password='a0415312',
                           db='openair', charset='utf8')
    try:
        # Connection 으로부터  Cursor 생성
        # UPDATE
        with conn.cursor() as curs:
            sql = """update realtimew set date = %s, PM10con = %s, PM25con = %s, PM10level = %s, PM25level = %s where place = %s"""
            curs.executemany(sql, info)

        conn.commit()

        # SELECT
        with conn.cursor() as curs:
            sql = "select * FROM realtimew"
            curs.execute(sql)
            rs = curs.fetchall()
            for row in rs:
                print(row)

    finally:
        conn.close()

#오늘 내일 예보 정보 sql 저장
def tomorroww_insert(info):
    # MySQL Connection 연결
    conn = pymysql.connect(host='localhost', user='root', password='a0415312',
                           db='openair', charset='utf8')
    try:
        # Connection 으로부터  Cursor 생성
        # UPDATE
        with conn.cursor() as curs:
            sql = """insert into tomorroww(place, time, PM10level, PM25level, date) values (%s, %s, %s, %s, %s)"""
            curs.executemany(sql, info)

        conn.commit()

        # SELECT
        with conn.cursor() as curs:
            sql = "select * FROM tomorroww"
            curs.execute(sql)
            rs = curs.fetchall()
            for row in rs:
                print(row)

    finally:
        conn.close()

#오늘 내일 예보 정보 sql 저장
def forecastw_insert(info):
    # MySQL Connection 연결
    conn = pymysql.connect(host='localhost', user='root', password='a0415312',
                           db='openair', charset='utf8')
    try:
        # Connection 으로부터  Cursor 생성
        # UPDATE
        with conn.cursor() as curs:
            sql = """insert into forecastw(place, date, time, PM10level, PM25level) values (%s, %s, %s, %s, %s)"""
            curs.executemany(sql, info)

        conn.commit()

        # SELECT
        with conn.cursor() as curs:
            sql = "select * FROM forecastw"
            curs.execute(sql)
            rs = curs.fetchall()
            for row in rs:
                print(row)

    finally:
        conn.close()