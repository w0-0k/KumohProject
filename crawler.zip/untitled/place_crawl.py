#이 모듈은 한번만 실행

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

areanumber = ["02", "031", "032", "033", "041", "042", "043", "051", "052", "053",
              "054", "055", "061", "062", "063", "064", "044"]

#크롬 드라이버 위치 확인 후 실행
driver = webdriver.Chrome("C:/Users/JangWook/Documents/driver/chromedriver")

#에어코리아 측정소 정보 실행
driver.get("https://www.airkorea.or.kr/web/stationInfo?pMENU_NO=93")
time.sleep(1)

def place_crawl():

    placelist = []
    addresslist = []

    for i in areanumber:
        #driver.implicitly_wait(2)
        driver.find_element_by_xpath("//area[@class='submap"+i+"']").send_keys(Keys.ENTER) #지도 내의 지역을 클릭하여 측정소 정보를 조회
        driver.implicitly_wait(2)
        #time.sleep(1) #ip 차단 방지

        html = driver.page_source
        soup = BeautifulSoup(html, 'lxml')  #페이지 파싱


        place = soup.select("#cont_body > form > div > div.divi_r.W55p.MgT10 > table > tbody > tr > th")
        address = soup.select("#cont_body > form > div > div.divi_r.W55p.MgT10 > table > tbody > tr > td")

        for data in place:  # 복수의 정보들에서 하나씩 꺼내어
            placelist.append(data.text)

        for data in address:
            addresslist.append(data.text)

    driver.close()

    info = []

    for i in range(len(placelist)): #측정소 개수 많은 반복
        #지역 타입 일치화
        if "경상북도" in addresslist[i]:
            addresslist[i] = addresslist[i].replace('경상북도','경북')
        if "야음동" == placelist[i]:
            addresslist[i] = "울산 " + addresslist[i]

        info.append((placelist[i], addresslist[i])) #리스트 타입 내에 2개의 요소를 포함한 튜플을 추가

    return tuple(info) #리스트 타입의 info를 튜플 타입으로 변경 후 리턴
