from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from datetime import date, timedelta

# 지역번호
areanumber = ["3", "4", "5", "6", "7", "8", "9", "10", "11", "12",
              "13", "14", "15", "16", "17", "18", "19","20","21"]
#
time_clock = ["오늘 00시","오늘 03시","오늘 06시","오늘 09시","오늘 12시","오늘 15시","오늘 18시","오늘 21시"
        ,"내일 00시","내일 03시","내일 06시","내일 09시","내일 12시","내일 15시","내일 18시","내일 21시"]

two = date.today() + timedelta(2)
three = date.today() + timedelta(3)
four = date.today() + timedelta(4)

#당일과 내일 예보
def tweather_crawl():
    # 크롬 드라이버 위치 확인 후 실행
    driver = webdriver.Chrome("C:/Users/JangWook/Documents/driver/chromedriver")
    driver.implicitly_wait(3)
    # 에어코리아 측정소 정보 실행
    driver.get("http://kweather.co.kr/air/air_forecast_3hr.html")

    list = []
    for i in areanumber:
        driver.find_element_by_xpath("//*[@id='Map']/area[" + i + "]").send_keys(Keys.ENTER)
        driver.implicitly_wait(2)
        html = driver.page_source
        soup = BeautifulSoup(html, 'lxml')

        # 발표일 받아오기
        date = soup.select("#air_dataTime2")
        # 지역이름 받기
        location = soup.select("#airforecast_data_div > ul:nth-child(1) > span.air_forecast_area")
        # 미세먼지 상태 받기
        finedust = soup.select("#dataTable_3hr > table > tbody > tr.data_pm10_time > td")
        # 초미세먼지 상태 받기
        U_finedust = soup.select("#dataTable_3hr > table > tbody > tr.data_pm25_time > td")

        # 오늘 미세먼지 상태 00~21시까지 받아옴
        for i in range(1, len(finedust)):
            list.append((location[0].text, time_clock[i - 1], finedust[i].text, U_finedust[i].text, date[0].text))

    driver.close()
    return tuple(list)

#모레, 모레+1, 모레+2 예보
def fweather_crawl():
    # 크롬 드라이버 위치 확인 후 실행
    driver = webdriver.Chrome("C:/Users/JangWook/Documents/driver/chromedriver")
    driver.implicitly_wait(3)
    # 에어코리아 측정소 정보 실행
    driver.get("http://kweather.co.kr/air/air_forecast_3hr.html")

    list = []

    for i in areanumber:
        driver.find_element_by_xpath("//*[@id='Map']/area[" + i + "]").send_keys(Keys.ENTER)
        driver.implicitly_wait(2)
        html = driver.page_source
        soup = BeautifulSoup(html, 'lxml')

        location = soup.select("#airforecast_data_div > ul:nth-child(1) > span.air_forecast_area")
        date = [two.strftime('%Y-%m-%d'), three.strftime('%Y-%m-%d'), four.strftime('%Y-%m-%d')]
        ampm = soup.select("#dataTable_day > table > tbody > tr.bg_whitesky > td")
        a_finedust = soup.select("#dataTable_day > table > tbody > tr.data_pm10_half > td")
        a_U_finedust = soup.select("#dataTable_day > table > tbody > tr.data_pm25_half > td")

        for k in range(1, 7):
            list.append((location[0].text, date[int((k - 1) / 2)], ampm[k].text, a_finedust[k].text.lstrip(' '),
                         a_U_finedust[k].text.lstrip(' ')))

    driver.close()
    return tuple(list)