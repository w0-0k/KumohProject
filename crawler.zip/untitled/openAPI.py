#이 모듈은 한 시간마다 동작

import urllib.parse
import urllib.request
import json
import access_DB as db

areaname = ["서울", "경기", "인천", "강원", "충남", "대전", "충북", "부산", "울산",
            "대구", "경북", "경남", "전남", "광주", "전북", "제주", "세종"]

ServiceKey = "IKSdOfyn95SYlPoc8mu0z8Yr%2BOh%2FBoM6%2FnXvxjw8uzxUJpG7wLnaryk4FvVrVeVy6%2FnrEYLI5TwYMGfHOnfvnQ%3D%3D&_returnType=json&ver=1.3"

areaToUni = []

def request_api():
    tup = []
    for i in range(len(areaname)):
        areaToUni.append(urllib.parse.quote(areaname[i], safe=''))
        url = "http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty?sidoName=" + \
        areaToUni[i] + "&pageNo=1&numOfRows=100&ServiceKey=IKSdOfyn95SYlPoc8mu0z8Yr%2BOh%2FBoM6%2FnXvxjw8uzxUJpG7wLnaryk4FvV" \
                       "rVeVy6%2FnrEYLI5TwYMGfHOnfvnQ%3D%3D&_returnType=json&ver=1.3"

        request = urllib.request.Request(url)
        response = urllib.request.urlopen(request)
        rescode = response.getcode()



        if (rescode == 200):
            response_body = response.read().decode('utf-8')
            json_data = json.loads(response_body)

            for i in range(len(json_data['list'])):

                stationName = json_data['list'][i]['stationName']
                dateTime = json_data['list'][i]['dataTime']
                pm10Value = json_data['list'][i]['pm10Value']
                pm25Value = json_data['list'][i]['pm25Value']
                pm10Grade1H = json_data['list'][i]['pm10Grade1h']
                pm25Grade1H = json_data['list'][i]['pm25Grade1h']

                tup.append((dateTime+' 발표', pm10Value, pm25Value, pm10Grade1H, pm25Grade1H, stationName))

        else:
            print("Error Code:" + rescode)

    return tuple(tup)