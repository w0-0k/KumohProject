import place_crawl as pc
import access_DB as db
import openAPI as api
import weather_crawl as wc

def main():
    #측정소명과 주소 저장 - 한번만 실행, 한번 돌리고 지우면 됨
    # place_crawl.py
    info = pc.place_crawl()
    # access_DB.py
    db.place_insert(info)

    #실시간 데이터 저장 - 1시간 단위로 업데이트
    # openAPI.py
    info = api.request_api()
    # access_DB.py
    db.realtimew_update(info)

    #오늘, 내일 ,모레, 등등 예보 데이터 저장 - 하루에 몇번 업데이트
    # weather_crawl.py
    info = wc.tweather_crawl()
    # access_DB.py
    db.tomorroww_insert(info)

    # weather_crawl.py
    info = wc.fweather_crawl()
    # access_DB.py
    db.forecastw_insert(info)


if __name__ == "__main__":
    main()





